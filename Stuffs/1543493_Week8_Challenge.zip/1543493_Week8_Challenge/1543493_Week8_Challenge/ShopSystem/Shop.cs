﻿using _1543493_Week8_Challenge.ClientContent;
using _1543493_Week8_Challenge.ItemContent;
using _1543493_Week8_Challenge.SaveSystem;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using static _1543493_Week8_Challenge.ItemContent.Item;

namespace _1543493_Week8_Challenge.ShopSystem
{
    public class Shop
    {
        public static bool running = true;

        public SaveData saveData = new SaveData();

        public Client client;
        public List<Client> clientList = new List<Client>();

        public List<Item> bazaarInventory = new List<Item>();

        public void InShop()
        {
            Shop shop = InitShop();

            while (running)
            {
                string shopBranch = ShopMainMenu(shop);
                switch (shopBranch)
                {
                    case "1":
                        {
                            ClientPurchaseArms(shop.client, shop);
                        }
                        break;
                }
            }
        }

        private static Shop InitShop()
        {
            Shop shop = new Shop();
            if (Directory.Exists("Saves"))
            {

            }
            else
            {
                Directory.CreateDirectory("Saves");
            }

            if (File.Exists(@"Saves\save.json"))
            {
                shop.saveData = SaveData.LoadShop();
                shop.client = shop.saveData.currentClient;
                shop.clientList = shop.saveData.clientList;
                shop.bazaarInventory = shop.saveData.bazaarInventory;
            }
            else
            {
                Utilities.PrintShopBanner();
                shop.bazaarInventory = InitShopInventory();
                shop.client = Client.InitClient(shop.client, shop.clientList);
                shop.clientList.Add(shop.client);
                shop.saveData.currentClient = shop.client;
                shop.saveData.clientList = shop.clientList;
                shop.saveData.SaveShop();
            }
            return shop;
        }

        private static List<Item> InitShopInventory()
        {
            List<Item> list = new List<Item>();

            Item ak47 = new Item("AK-47", "Reliable, 7.62x39mm automatic rifle, unrivalled in its power under environmental stress.", Item.ItemType.SmallArms, 759.95m)
            {
                stock = 2000
            };

            Item pkm = new Item("PKM", "Unrelenting, 7.62x54mmR machine gun.", Item.ItemType.SmallArms, 995.99m)
            {
                stock = 800
            };

            Item rpg7 = new Item("RPG-7", "Unguided, handheld, reusable rocket launcher.", Item.ItemType.SmallArms, 1250.99m)
            {
                stock = 1200
            };

            Item toyotaHilux = new Item("Toyota Hilux", "A robust, no-nonsense all-terrain pickup truck, ready for HMG attachments.", Item.ItemType.GroundVehicles, 46885m)
            {
                stock = 100
            };

            Item t34 = new Item("T-34/76", "An old, inexpensive Soviet tank mass-produced during the second world war.", Item.ItemType.GroundVehicles, 230000m)
            {
                stock = 50
            };

            Item abrams = new Item("M1 Abrams", "The top of the line from Shifting Sands. Civil wars can be fought with only a handful of cutting-edge battle tanks.", Item.ItemType.GroundVehicles, 6200000m)
            {
                stock = 8
            };

            Item raven = new Item("R-44 Raven II", "A standard civilian helicopter, capable of carrying a small fireteam and some equipment.", Item.ItemType.AerialVehicles, 465000m)
            {
                stock = 20
            };

            Item mh6 = new Item("MH-6 Little Bird", "A small, agile helicopter capable of housing machine guns and rockets. Small bird, big caw.", Item.ItemType.AerialVehicles, 2000000m)
            {
                stock = 10
            };

            Item apache = new Item("AH-64 Apache", "The apex predator of the sky. Comes with thermal imaging, explosive machine guns and missiles. Fear the skies.", Item.ItemType.AerialVehicles, 930000000m)
            {
                stock = 5
            };

            list.Add(ak47);
            list.Add(pkm);
            list.Add(rpg7);
            list.Add(toyotaHilux);
            list.Add(t34);
            list.Add(abrams);
            list.Add(raven);
            list.Add(mh6);
            list.Add(apache);

            return list;
        }

        private static string ShopMainMenu(Shop shop)
        {
            Utilities.PrintShopBanner();
            Console.WriteLine($"\nWelcome to the Shifting Sands Bazaar. We wish you a pleasant experience whilst browsing our armaments.");

            shop.client.PrintClientBalance();

            string input = Utilities.GetUserInput("\n____ Main Menu ____\n" +
                "\n1. Buy armaments" +
                "\n2. Sell armaments" +
                "\n3. Review/Edit basket" +
                "\n4. Review client's inventory");

            return input;
        }

        private static void ClientPurchaseArms(Client client, Shop shop)
        {
            Console.Clear();
            Utilities.PrintShopBanner();
            PrintShopInventory(shop.bazaarInventory);
        }

        private static void ClientSellArms()
        {

        }

        private static void ClientReviewBasket()
        {

        }

        private static void ClientReviewInventory()
        {

        }

        private static void PrintShopInventory(List<Item> list)
        {
            list.Sort((itemA, itemB) => itemA.itemType.CompareTo(itemB.itemType));

            string[] categories = new string[] { ">> Small Arms <<", ">> Ground Vehicles <<", ">> Aerial Vehicles <<" };
            ItemType previousItemType = 0;

            for (int i = 0; i < list.Count; i++)
            {
                Item item = list[i];

                if (previousItemType != item.itemType || i == 0)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.WriteLine(categories[(int)item.itemType]);
                    Console.ResetColor();
                }

                Console.WriteLine($"\n{i + 1}. {item}\n");
                previousItemType = item.itemType;
            }
        }
    }
}
