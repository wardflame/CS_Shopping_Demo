﻿using _1543493_Week8_Challenge.ShopSystem;
using System;

namespace _1543493_Week8_Challenge
{
    class Program
    {
        static void Main(string[] args)
        {
            Shop shop = new Shop();
            shop.InShop();
        }
    }
}
