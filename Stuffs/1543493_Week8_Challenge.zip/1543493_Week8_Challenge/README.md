### 7/10 ###
- [x] Player class
- string name
- string description
- decimal balance
- List<> inventory

- [ ] Shop
- 5 unique items (minimum)
- basket that holds items
