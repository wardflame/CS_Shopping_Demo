﻿using _1543493_Week8_Challenge.ShopSystem;
using System;

namespace _1543493_Week8_Challenge
{
    // 1543493 | 18/11/2021 02:40 | v0.0.0.3
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(130, 75);
            Shop.InShop();
        }
    }
}
